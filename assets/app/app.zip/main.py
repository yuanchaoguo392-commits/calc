import flet as ft
def main(page: ft.Page):
    page.add(ft.Text("你好，世界！成功了！", size=50, color="green"))
ft.app(target=main)