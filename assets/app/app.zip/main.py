import flet as ft
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import io
import base64
import os
import csv
import sys

# 强制使用非交互式后端
matplotlib.use("Agg")


def main(page: ft.Page):
    # --- 1. 页面设置 ---
    page.title = "直线度计算系统"
    page.theme_mode = "light"  # 改用字符串，更安全
    page.bgcolor = "#F0F0F0"
    page.scroll = "adaptive"  # 改用字符串
    page.padding = 10

    pick_dialog = ft.FilePicker()
    save_dialog = ft.FilePicker()
    page.overlay.extend([pick_dialog, save_dialog])

    # 状态变量
    input_rows = []
    res_max = ft.Ref[ft.Text]()
    res_min = ft.Ref[ft.Text]()
    res_range = ft.Ref[ft.Text]()
    res_straight = ft.Ref[ft.Text]()

    # 图表 (预设空图)
    empty_img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
    # 【关键修改】这里改回了 "contain"，不用 ft.ImageFit
    chart_image = ft.Image(src=empty_img, fit="contain")

    # --- 辅助函数 ---
    def get_float(value, default=0.0):
        try:
            return float(value)
        except:
            return default

    def update_chart(x_data, y_data):
        fig, ax = plt.subplots(figsize=(5, 4))
        fig.subplots_adjust(left=0.15, right=0.95, top=0.95, bottom=0.15)
        fig.patch.set_facecolor('#F0F0F0')
        ax.set_facecolor('#F0F0F0')

        if len(x_data) > 0:
            ax.plot(x_data, y_data, 's-', color='red', linewidth=1, label='Grid')
            ax.axhline(0, color='gray', linestyle=':')
            ax.grid(True, linestyle=':', alpha=0.5)
        else:
            ax.text(0.5, 0.5, "Waiting...", ha='center', color='gray')

        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        img_str = base64.b64encode(buf.getvalue()).decode("utf-8")
        chart_image.src_base64 = img_str
        chart_image.update()
        page.update()

    def recalculate(e=None):
        bridge_len = get_float(txt_bridge.value, 200.0)
        mode = radio_group.value

        measures = []
        has_data = False
        for row in input_rows:
            val_str = row["measure"].value.strip()
            if val_str:
                has_data = True
                measures.append(get_float(val_str))
            else:
                measures.append(0.0)

        if not input_rows or not has_data:
            res_max.current.value = "0.0"
            res_min.current.value = "0.0"
            res_range.current.value = "0.0"
            res_straight.current.value = "0.0"
            update_chart([], [])
            page.update()
            return

        n = len(measures)
        diffs, accs, mids, strs = [], [], [], []
        start_val = measures[0]
        curr_acc = 0.0

        for m in measures:
            d = m - start_val
            diffs.append(d)
            curr_acc += d
            accs.append(curr_acc)

        step = accs[-1] / n if n > 0 else 0.0
        for i in range(n):
            mid = (i + 1) * step
            mids.append(mid)
            strs.append(round(accs[i] - mid, 1))

        # 更新表格
        for i in range(n):
            if input_rows[i]["measure"].value.strip():
                input_rows[i]["diff"].value = f"{diffs[i]:.1f}"
                input_rows[i]["acc"].value = f"{accs[i]:.1f}"
                input_rows[i]["mid"].value = f"{mids[i]:.1f}"
                input_rows[i]["str"].value = f"{strs[i]:.1f}"
            else:
                for key in ["diff", "acc", "mid", "str"]:
                    input_rows[i][key].value = ""

        mx, mn = max(strs), min(strs)
        grid_val = mx - mn

        if mode == "flatness":
            divisor = 200.0
        elif mode == "level":
            divisor = 50.0
        elif mode == "elec":
            divisor = 100.0
        else:
            divisor = 200.0

        straightness_val = grid_val * (bridge_len / divisor)

        res_max.current.value = f"{mx:.1f}"
        res_min.current.value = f"{mn:.1f}"
        res_range.current.value = f"{grid_val:.1f}"
        res_straight.current.value = f"{straightness_val:.1f}"

        update_chart(range(1, n + 1), strs)
        page.update()

    def create_row_control(index, val=""):
        def on_enter_pressed(e):
            next_idx = index + 1
            if next_idx < len(input_rows):
                input_rows[next_idx]["measure"].focus()

        txt_measure = ft.TextField(
            value=val, width=60, text_align="center",
            bgcolor="white", border_color="#DDDDDD", height=35,
            content_padding=5, text_size=14,
            keyboard_type=ft.KeyboardType.NUMBER,
            on_change=recalculate,
            on_submit=on_enter_pressed
        )
        txt_diff = ft.Text("", expand=1, text_align="center", size=12)
        txt_acc = ft.Text("", expand=1, text_align="center", size=12)
        txt_mid = ft.Text("", expand=1, text_align="center", size=12)
        txt_str = ft.Text("", expand=1, text_align="center", size=12, weight="bold", color="blue")

        input_rows.append({"measure": txt_measure, "diff": txt_diff, "acc": txt_acc, "mid": txt_mid, "str": txt_str})

        rows_column.controls.append(
            ft.Container(
                content=ft.Row(
                    [
                        ft.Container(ft.Text(f"{index + 1}", text_align="center"), width=40),
                        ft.Container(txt_measure, width=80),
                        txt_diff, txt_acc, txt_mid, txt_str
                    ],
                    alignment="start", spacing=0
                ),
                bgcolor="white", padding=2,
                border=ft.border.only(bottom=ft.border.BorderSide(1, "#EEEEEE"))
            )
        )

    def auto_resize_table(e):
        try:
            target = int(txt_count.value)
        except:
            target = 0
        if target < 0: target = 0
        current = len(input_rows)
        if target == current: return
        existing = [row["measure"].value for row in input_rows]
        input_rows.clear()
        rows_column.controls.clear()
        for i in range(target):
            val = existing[i] if i < len(existing) else ""
            create_row_control(i, val)
        page.update()
        recalculate()

    def clear_all(e):
        for row in input_rows:
            row["measure"].value = ""
            for k in ["diff", "acc", "mid", "str"]: row[k].value = ""
        recalculate()

    # --- 导入/导出逻辑 ---
    def on_import_result(e: ft.FilePickerResultEvent):
        if not e.files: return
        file_path = e.files[0].path
        try:
            new_vals = []
            imported_bridge = None

            if file_path.endswith('.xlsx') or file_path.endswith('.xls'):
                try:
                    meta_df = pd.read_excel(file_path, header=None, nrows=2)
                    if meta_df.iloc[0, 0] == "板桥长度":
                        val = meta_df.iloc[0, 1]
                        if pd.notna(val): imported_bridge = str(val)
                        df_data = pd.read_excel(file_path, header=3)
                        if "测量值" in df_data.columns: new_vals = df_data["测量值"].dropna().tolist()
                    else:
                        raise Exception("Not custom format")
                except:
                    df = pd.read_excel(file_path)
                    if "测量值" in df.columns:
                        new_vals = df["测量值"].dropna().tolist()
                    elif "Measure" in df.columns:
                        new_vals = df["Measure"].dropna().tolist()
                    elif df.shape[1] >= 2:
                        new_vals = df.iloc[:, 1].dropna().tolist()
                    else:
                        new_vals = df.iloc[:, 0].dropna().tolist()

            elif file_path.endswith('.csv'):
                with open(file_path, "r", encoding="utf-8-sig") as f:
                    reader = csv.reader(f)
                    header = next(reader, None)
                    col_idx = 1
                    if header and "测量值" in header: col_idx = header.index("测量值")
                    for row in reader:
                        if len(row) > col_idx:
                            new_vals.append(row[col_idx])
                        elif len(row) == 1:
                            new_vals.append(row[0])

            if new_vals:
                if imported_bridge: txt_bridge.value = imported_bridge
                txt_count.value = str(len(new_vals))
                input_rows.clear()
                rows_column.controls.clear()
                for i, val in enumerate(new_vals): create_row_control(i, str(val))
                recalculate()
                page.show_snack_bar(ft.SnackBar(ft.Text("导入成功")))
            else:
                page.show_snack_bar(ft.SnackBar(ft.Text("未读取到数据")))
        except Exception as ex:
            page.show_snack_bar(ft.SnackBar(ft.Text(f"导入出错: {ex}")))

    def on_export_result(e: ft.FilePickerResultEvent):
        if not e.path: return
        try:
            bridge_val = txt_bridge.value
            count_val = txt_count.value
            v_max = res_max.current.value
            v_min = res_min.current.value
            v_range = res_range.current.value
            v_str = res_straight.current.value
            data = []
            for idx, row in enumerate(input_rows):
                m = row["measure"].value.strip()
                if m:
                    data.append({
                        "序号": idx + 1, "测量值": float(m),
                        "差值": row["diff"].value, "积": row["acc"].value,
                        "中间值": row["mid"].value, "直线度": row["str"].value
                    })
            if not data:
                page.show_snack_bar(ft.SnackBar(ft.Text("无数据")))
                return
            df = pd.DataFrame(data)

            if e.path.endswith(".xlsx"):
                with pd.ExcelWriter(e.path, engine='openpyxl') as writer:
                    df.to_excel(writer, sheet_name='Sheet1', startrow=3, index=False)
                    ws = writer.sheets['Sheet1']
                    ws['A1'], ws['B1'] = "板桥长度", float(bridge_val) if bridge_val else 0
                    ws['C1'], ws['D1'] = "平数", int(count_val) if count_val else 0
                    ws['A2'], ws['B2'] = "最大", float(v_max)
                    ws['C2'], ws['D2'] = "最小", float(v_min)
                    ws['E2'], ws['F2'] = "格值", float(v_range)
                    ws['G2'], ws['H2'] = "直线度", float(v_str)
            elif e.path.endswith(".csv"):
                df.to_csv(e.path, index=False, encoding="utf-8-sig")
            page.show_snack_bar(ft.SnackBar(ft.Text(f"保存成功")))
        except Exception as ex:
            page.show_snack_bar(ft.SnackBar(ft.Text(f"保存失败: {ex}")))

    pick_dialog.on_result = on_import_result
    save_dialog.on_result = on_export_result

    # --- 控件初始化 ---
    txt_bridge = ft.TextField(label="板桥长度", value="200", width=100, height=40, text_size=14, on_change=recalculate)
    txt_count = ft.TextField(label="平数", width=80, height=40, text_size=14, on_change=auto_resize_table)

    def create_radio_option(val, text):
        return ft.Row([
            ft.Radio(value=val), ft.Text(text, size=14)
        ], spacing=0, alignment="start")

    radio_group = ft.RadioGroup(
        content=ft.Row([
            create_radio_option("flatness", "平面度"),
            create_radio_option("level", "水平仪"),
            create_radio_option("elec", "电子检查")
        ], alignment="spaceBetween"),
        value="flatness", on_change=recalculate
    )

    btn_import = ft.ElevatedButton("导入", icon="upload_file",
                                   on_click=lambda _: pick_dialog.pick_files(allowed_extensions=["xlsx", "xls", "csv"]))
    btn_clear = ft.ElevatedButton("清除", icon="clear", on_click=clear_all, color="red")
    btn_export = ft.ElevatedButton("导出", icon="save_alt",
                                   on_click=lambda _: save_dialog.save_file(file_name="result.xlsx",
                                                                            allowed_extensions=["xlsx"]))

    def create_dash(title, ref):
        return ft.Container(
            content=ft.Column([
                ft.Text(title, size=12, color="grey"),
                ft.Text(value="0.0", ref=ref, size=20, weight="bold")
            ], alignment="center"),
            bgcolor="white", padding=5, border_radius=5, expand=True
        )

    dashboard = ft.Row([
        create_dash("最大", res_max), create_dash("最小", res_min),
        create_dash("格值", res_range), create_dash("直线度", res_straight)
    ])

    header = ft.Container(
        content=ft.Row([
            ft.Container(ft.Text("No.", text_align="center"), width=40),
            ft.Container(ft.Text("测量", text_align="center"), width=80),
            ft.Text("差", text_align="center", expand=1),
            ft.Text("积", text_align="center", expand=1),
            ft.Text("中间值", text_align="center", expand=1),
            ft.Text("结果", text_align="center", expand=1),
        ], alignment="start", spacing=0),
        bgcolor="#E0E0E0", padding=5
    )
    rows_column = ft.Column(scroll="always")

    # --- 布局 ---
    page.add(
        ft.Column([
            ft.Container(
                ft.Column([
                    ft.Row([txt_bridge, txt_count]),
                    radio_group,
                    ft.Row([btn_import, btn_clear, btn_export], alignment="spaceBetween")
                ]), bgcolor="white", padding=10, border_radius=10, margin=ft.margin.only(top=25)
            ),
            dashboard,
            ft.Container(
                ft.Column([header, ft.Container(rows_column, height=250)]),
                bgcolor="white", padding=5, border_radius=10
            ),
            ft.Column([
                ft.Text("误差曲线", size=14, weight="bold"),
                ft.Container(chart_image, bgcolor="#F0F0F0", border_radius=10)
            ])
        ], scroll="adaptive")
    )


if __name__ == "__main__":
    ft.app(target=main)
