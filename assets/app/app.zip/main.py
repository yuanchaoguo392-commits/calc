
import flet as ft
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import io
import base64
import os
import csv
import sys


print("当前运行的解释器:", sys.executable)
print("当前 Flet 版本:", ft.version)

matplotlib.use("Agg")


def main(page: ft.Page):

    pick_dialog = ft.FilePicker()
    save_dialog = ft.FilePicker()
    # --- 1. 页面设置 ---
    page.title = "法尔机电--直线度计算系统"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = "#F0F0F0"
    page.scroll = ft.ScrollMode.ADAPTIVE
    page.padding = 10

    # 状态变量
    input_rows = []
    res_max = ft.Ref[ft.Text]()
    res_min = ft.Ref[ft.Text]()
    res_range = ft.Ref[ft.Text]()
    res_straight = ft.Ref[ft.Text]()

    # 图表 (预设空图防报错)
    empty_img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
    chart_image = ft.Image(src=empty_img, width=600, height=300, fit="contain")

    # --- 2. 核心逻辑 (完全复刻您的 Tkinter 版本) ---
    def get_float(value, default=0.0):
        try:
            return float(value)
        except:
            return default

    def update_chart(x_data, y_data):
        fig, ax = plt.subplots(figsize=(5, 4))
        # 调整边距
        fig.subplots_adjust(left=0.15, right=0.95, top=0.95, bottom=0.15)
        # 设置背景色
        fig.patch.set_facecolor('#F0F0F0')
        ax.set_facecolor('#F0F0F0')

        if len(x_data) > 0:
            ax.plot(x_data, y_data, 's-', color='red', linewidth=1, label='Grid')
            ax.axhline(0, color='gray', linestyle=':')
            ax.grid(True, linestyle=':', alpha=0.5)
        else:
            ax.text(0.5, 0.5, "Waiting...", ha='center', color='gray')

        buf = io.BytesIO()
        # 必须确保是用 png 格式
        fig.savefig(buf, format='png', dpi=100)
        plt.close(fig)

        # 获取纯 Base64 字符串
        img_str = base64.b64encode(buf.getvalue()).decode("utf-8")

        # 【关键修复】使用 src_base64，且不要加前缀
        chart_image.src = ""  # 先清空旧的 src，防止冲突
        chart_image.src_base64 = img_str  # 直接给纯字符

        chart_image.update()
        page.update()

    def recalculate(e=None):
        bridge_len = get_float(txt_bridge.value, 200.0)
        mode = radio_group.value

        measures = []
        has_data = False

        for row in input_rows:
            val_str = row["measure"].value.strip()
            if val_str:
                has_data = True
                measures.append(get_float(val_str))
            else:
                measures.append(0.0)

        n = len(measures)
        diffs, accs, mids, strs = [], [], [], []

        if not input_rows or not has_data:
            res_max.current.value = "0.0"
            res_min.current.value = "0.0"
            res_range.current.value = "0.0"
            res_straight.current.value = "0.0"
            update_chart([], [])
            page.update()
            return

        # === 核心算法 (100% 复刻 Tkinter 逻辑) ===
        start_val = measures[0]
        curr_acc = 0.0
        for m in measures:
            d = m - start_val
            diffs.append(d)
            curr_acc += d
            accs.append(curr_acc)

        step = accs[-1] / n if n > 0 else 0.0
        for i in range(n):
            mid = (i + 1) * step
            mids.append(mid)
            # 关键：中间值修约保留1位小数
            strs.append(round(accs[i] - mid, 1))

        # 更新表格
        for i in range(n):
            if input_rows[i]["measure"].value.strip():
                input_rows[i]["diff"].value = f"{diffs[i]:.1f}"
                input_rows[i]["acc"].value = f"{accs[i]:.1f}"
                input_rows[i]["mid"].value = f"{mids[i]:.1f}"
                input_rows[i]["str"].value = f"{strs[i]:.1f}"
            else:
                for key in ["diff", "acc", "mid", "str"]:
                    input_rows[i][key].value = ""

        # 更新结果
        # 注意：strs 已经是修约后的值，所以 Max/Min 也是修约后的
        mx, mn = max(strs), min(strs)
        grid_val = mx - mn

        # 关键：分母判定逻辑
        if mode == "flatness":
            divisor = 200.0
        elif mode == "level":
            divisor = 50.0
        elif mode == "elec":
            divisor = 100.0
        else:
            divisor = 200.0

        straightness_val = grid_val * (bridge_len / divisor)

        res_max.current.value = f"{mx:.1f}"
        res_min.current.value = f"{mn:.1f}"
        res_range.current.value = f"{grid_val:.1f}"
        res_straight.current.value = f"{straightness_val:.1f}"

        update_chart(range(1, n + 1), strs)
        page.update()

    def create_row_control(index, val=""):
        def on_enter_pressed(e):
            # 获取当前是第几行
            current_idx = index
            # 目标是下一行 (index + 1)
            next_idx = current_idx + 1

            # 检查下一行是否存在
            if next_idx < len(input_rows):
                # 存在：直接聚焦下一行的输入框
                input_rows[next_idx]["measure"].focus()
            else:
                # 不存在（已经是最后一行）：可选逻辑 -> 自动新增一行并聚焦
                # 如果不需要自动新增，可以把下面这两行删掉
                # current_count = int(txt_count.value) if txt_count.value else 0
                # txt_count.value = str(current_count + 1)
                # auto_resize_table(None)
                pass  # 这里暂时什么都不做，防止误操作

        txt_measure = ft.TextField(
            value=val, width=60, text_align="center",
            bgcolor="white", border_color="#DDDDDD", height=35,
            content_padding=5, text_size=14,
            keyboard_type=ft.KeyboardType.NUMBER,
            on_change=recalculate,
            on_submit=on_enter_pressed
        )
        txt_diff = ft.Text("", expand=1, text_align="center", size=12)
        txt_acc = ft.Text("", expand=1, text_align="center", size=12)
        txt_mid = ft.Text("", expand=1, text_align="center", size=12)
        txt_str = ft.Text("", expand=1, text_align="center", size=12, weight="bold", color="blue")

        input_rows.append({"measure": txt_measure, "diff": txt_diff, "acc": txt_acc, "mid": txt_mid, "str": txt_str})

        rows_column.controls.append(
            ft.Container(
                content=ft.Row(
                    [
                        ft.Container(ft.Text(f"{index + 1}", text_align="center"), width=40),
                        ft.Container(txt_measure, width=80),
                        txt_diff, txt_acc, txt_mid, txt_str
                    ],
                    alignment=ft.MainAxisAlignment.START, spacing=0
                ),
                bgcolor="white", padding=2,
                border=ft.border.only(bottom=ft.border.BorderSide(1, "#EEEEEE"))
            )
        )

    def auto_resize_table(e):
        try:
            target = int(txt_count.value)
        except:
            target = 0
        if target < 0: target = 0

        current = len(input_rows)
        if target == current: return

        existing = [row["measure"].value for row in input_rows]
        input_rows.clear()
        rows_column.controls.clear()

        for i in range(target):
            val = existing[i] if i < len(existing) else ""
            create_row_control(i, val)

        page.update()
        recalculate()

    def clear_all(e):
        for row in input_rows:
            row["measure"].value = ""
            for k in ["diff", "acc", "mid", "str"]: row[k].value = ""
        recalculate()

    # === 插入点：Excel 导入/导出逻辑 ===

    # 1. 导入文件的逻辑
    def on_import_result(e: ft.FilePickerResultEvent):
        if not e.files: return
        file_path = e.files[0].path

        try:
            new_vals = []
            imported_bridge = None  # 用于存储从文件中读到的板桥长度

            # === 1. 处理 Excel ===
            if file_path.endswith('.xlsx') or file_path.endswith('.xls'):
                # 尝试策略 A：读取我们需要格式的表头（判断 A1 单元格是不是 "板桥长度"）
                try:
                    # 只读前两行元数据
                    meta_df = pd.read_excel(file_path, header=None, nrows=2)
                    if meta_df.iloc[0, 0] == "板桥长度":
                        # 这是一个标准的导出文件，读取板桥长度
                        val = meta_df.iloc[0, 1]
                        if pd.notna(val):
                            imported_bridge = str(val)

                        # 读取数据部分，表头在第 4 行 (header=3)
                        df_data = pd.read_excel(file_path, header=3)
                        # 读取 "测量值" 这一列
                        if "测量值" in df_data.columns:
                            new_vals = df_data["测量值"].dropna().tolist()
                    else:
                        # 不是标准文件，触发异常进入备用逻辑
                        raise Exception("Not custom format")
                except:
                    # 尝试策略 B：普通读取（假设全是数据，或者普通表头）
                    df = pd.read_excel(file_path)
                    # 优先找 "测量值" 或 "Measure" 列
                    if "测量值" in df.columns:
                        new_vals = df["测量值"].dropna().tolist()
                    elif "Measure" in df.columns:
                        new_vals = df["Measure"].dropna().tolist()
                    elif df.shape[1] >= 2:
                        # 如果没有表头，盲猜第2列是数据
                        new_vals = df.iloc[:, 1].dropna().tolist()
                    else:
                        # 实在不行取第1列
                        new_vals = df.iloc[:, 0].dropna().tolist()

            # === 2. 处理 CSV ===
            elif file_path.endswith('.csv'):
                with open(file_path, "r", encoding="utf-8-sig") as f:
                    reader = csv.reader(f)
                    header = next(reader, None)
                    # 简单判断一下 csv 结构
                    col_idx = 1
                    if header and "测量值" in header:
                        col_idx = header.index("测量值")

                    for row in reader:
                        if len(row) > col_idx:
                            new_vals.append(row[col_idx])
                        elif len(row) == 1:
                            new_vals.append(row[0])

            # === 3. 刷新界面 ===
            if new_vals:
                # 如果从文件中读到了板桥长度，自动填入
                if imported_bridge:
                    txt_bridge.value = imported_bridge

                # 更新平数
                txt_count.value = str(len(new_vals))

                # 重建表格
                input_rows.clear()
                rows_column.controls.clear()
                for i, val in enumerate(new_vals):
                    create_row_control(i, str(val))

                # 关键：触发计算，生成图表和结果
                recalculate()

                page.show_snack_bar(ft.SnackBar(ft.Text("导入成功，已自动计算")))
            else:
                page.show_snack_bar(ft.SnackBar(ft.Text("未读取到有效数据")))

        except Exception as ex:
            page.show_snack_bar(ft.SnackBar(ft.Text(f"出错: {ex}")))

    # 2. 导出文件的逻辑
    def on_export_result(e: ft.FilePickerResultEvent):
        if not e.path: return
        try:
            # === 1. 收集界面上的汇总数据 ===
            bridge_val = txt_bridge.value
            count_val = txt_count.value

            # 结果看板的数据
            v_max = res_max.current.value
            v_min = res_min.current.value
            v_range = res_range.current.value  # 格值
            v_str = res_straight.current.value  # 直线度结果

            # === 2. 收集表格详细数据 ===
            data = []
            for idx, row in enumerate(input_rows):
                m = row["measure"].value.strip()
                if m:
                    data.append({
                        "序号": idx + 1,
                        "测量值": float(m),
                        "差值": row["diff"].value,
                        "积": row["acc"].value,
                        "中间值": row["mid"].value,
                        "直线度": row["str"].value
                    })

            if not data:
                page.show_snack_bar(ft.SnackBar(ft.Text("无数据可导出")))
                return

            df = pd.DataFrame(data)

            # === 3. 保存逻辑 ===
            if e.path.endswith(".xlsx"):
                # 使用 openpyxl 引擎写入 Excel，方便操作单元格
                with pd.ExcelWriter(e.path, engine='openpyxl') as writer:
                    # 先把数据表写进去，从第 4 行开始 (startrow=3)，留出头部写参数
                    df.to_excel(writer, sheet_name='Sheet1', startrow=3, index=False)

                    # 获取工作表对象，手动写入头部信息
                    workbook = writer.book
                    sheet = writer.sheets['Sheet1']

                    # --- 第一行：输入参数 ---
                    sheet['A1'] = "板桥长度"
                    sheet['B1'] = float(bridge_val) if bridge_val else 0
                    sheet['C1'] = "平数"
                    sheet['D1'] = int(count_val) if count_val else 0

                    # --- 第二行：计算结果 ---
                    sheet['A2'] = "最大"
                    sheet['B2'] = float(v_max)
                    sheet['C2'] = "最小"
                    sheet['D2'] = float(v_min)
                    sheet['E2'] = "格值"
                    sheet['F2'] = float(v_range)
                    sheet['G2'] = "直线度(结果)"
                    sheet['H2'] = float(v_str)

                    # --- 调整一下列宽 (可选) ---
                    sheet.column_dimensions['B'].width = 12
                    sheet.column_dimensions['D'].width = 12
                    sheet.column_dimensions['F'].width = 12
                    sheet.column_dimensions['H'].width = 12

            # 如果用户非要存 CSV，就只存数据表（CSV 不支持复杂布局）
            elif e.path.endswith(".csv"):
                df.to_csv(e.path, index=False, encoding="utf-8-sig")

            page.show_snack_bar(ft.SnackBar(ft.Text(f"保存成功: {e.path}")))
        except Exception as ex:
            page.show_snack_bar(ft.SnackBar(ft.Text(f"保存失败: {ex}")))

    # === 插入点：初始化选择器（修复报错版） ===

    # 导入用的选择器
    pick_dialog.on_result = on_import_result  # <--- 关键：在这里绑定事件

    # 导出用的选择器
    save_dialog.on_result = on_export_result  # <--- 关键：在这里绑定事件





    # --- 3. UI 初始化 ---
    txt_bridge = ft.TextField(label="板桥长度", value="200", width=100, height=40, text_size=14,
                              keyboard_type=ft.KeyboardType.NUMBER, on_change=recalculate)
    txt_count = ft.TextField(label="平数", width=80, height=40, text_size=14, keyboard_type=ft.KeyboardType.NUMBER,
                             on_change=auto_resize_table)

    def create_option(val, text):
        return ft.Row(
            [
                ft.Container(
                    content=ft.Radio(value=val),
                    # 【修改点 1】宽度设为 24 (非常窄，只够放圆圈)
                    width=24,
                    height=40,
                    # 【修改点 2】使用 (0, 0) 代表完全居中
                    # 这样 Radio 左右两侧多余的空白都会被均匀“切掉”
                    alignment=ft.Alignment(0, 0),
                    padding=0,
                ),
                ft.Text(text, size=14)
            ],
            spacing=0,
            alignment=ft.MainAxisAlignment.START
        )

    # 【修改】使用新的 create_option 构建组件
    radio_group = ft.RadioGroup(
        content=ft.Row([
            create_option("flatness", "平面度检查仪"),
            create_option("level", "水平仪"),
            create_option("elec", "电子检查仪")
        ],
            # 这里保持之前的修改，让三组选项在屏幕上左右自适应对齐
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN),

        value="flatness", on_change=recalculate
    )

    btn_import = ft.ElevatedButton(
        "导入",
        icon="upload_file",
        on_click=lambda _: pick_dialog.pick_files(
            allowed_extensions=["xlsx", "xls", "csv"],
            dialog_title="请选择数据文件"
        )
    )
    btn_clear = ft.ElevatedButton("清除", icon="clear", on_click=clear_all, color="red")
    btn_export = ft.ElevatedButton(
        "导出",
        icon="save_alt",
        on_click=lambda _: save_dialog.save_file(
            file_name="直线度结果.xlsx",
            allowed_extensions=["xlsx"]
        )
    )

    def create_dash(title, ref):
        return ft.Container(
            content=ft.Column([
                ft.Text(title, size=13, color="grey"),
                ft.Text(value="0.0", ref=ref, size=24, weight="bold", color="black")
            ], alignment=ft.MainAxisAlignment.CENTER),
            bgcolor="white", padding=5, border_radius=5, expand=True
        )

    dashboard = ft.Row([
        create_dash("最大", res_max), create_dash("最小", res_min),
        create_dash("格值", res_range), create_dash("直线度", res_straight)
    ])

    header = ft.Container(
        content=ft.Row([
            ft.Container(ft.Text("No.", text_align="center"), width=40),
            ft.Container(ft.Text("测量", text_align="center"), width=80),
            ft.Text("差", text_align="center", expand=1),
            ft.Text("积", text_align="center", expand=1),
            ft.Text("中间值", text_align="center", expand=1),
            ft.Text("直线度", text_align="center", expand=1),
        ], alignment=ft.MainAxisAlignment.START, spacing=0),
        bgcolor="#E0E0E0", padding=5
    )
    rows_column = ft.Column()

    # --- 4. 最终布局 (修复间距问题) ---
    page.add(
        pick_dialog,  # <--- 把它们直接加到页面里，虽然不可见，但功能正常
        save_dialog,
        ft.Column(
            [
                ft.Container(
                    ft.Column([
                        ft.Row([txt_bridge, txt_count]),
                        radio_group,
                        ft.Row([btn_import, btn_clear, btn_export], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
                    ]),
                    bgcolor="white", padding=10, border_radius=10,
                    margin = ft.margin.only(top=25)
                ),
                dashboard,
                ft.Container(
                    ft.Column([header, ft.Column([rows_column], scroll=ft.ScrollMode.ALWAYS, height=200)]),
                    bgcolor="white", padding=5, border_radius=10
                ),
                # 【修改】这里去掉了 spacing，容器之间紧贴
                ft.Column([
                    ft.Text("误差曲线", size=14, weight="bold"),
                    ft.Container(chart_image, bgcolor="#F0F0F0", border_radius=10, padding=0, margin=0)
                ], spacing=2)  # 标题和图表只留 2 像素间距
            ],
            spacing=10,  # 大模块之间间距 10
            scroll=ft.ScrollMode.ADAPTIVE,
        )
    )


if __name__ == "__main__":
    # port 可以是任意端口，如 8000, 5000 等
    # host="0.0.0.0" 允许局域网设备访问
    # view=ft.AppView.WEB_BROWSER 自动在浏览器打开
    ft.app(target=main, view=ft.AppView.WEB_BROWSER, port=8000, host="localhost", assets_dir="assets")
