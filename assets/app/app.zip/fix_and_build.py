import os
import shutil
import subprocess

# 1. 强制修复编码
file_path = "main.py"
try:
    # 尝试读取文件（不管是 UTF-16 还是 GBK 还是 UTF-8）
    with open(file_path, "rb") as f:
        content = f.read()

    # 尝试解码
    text = None
    encodings = ["utf-8", "utf-16", "gbk", "utf-8-sig"]
    for enc in encodings:
        try:
            text = content.decode(enc)
            print(f"成功以 {enc} 格式读取文件。")
            break
        except:
            continue

    if text:
        # 强制用 UTF-8 无 BOM 格式写回
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(text)
        print("✅ main.py 已强制转换为 UTF-8 格式！")
    else:
        print("❌ 读取失败，无法识别编码。")
        exit()

except Exception as e:
    print(f"❌ 文件操作出错: {e}")
    exit()

# 2. 删除旧的 build 文件夹
if os.path.exists("build"):
    try:
        shutil.rmtree("build")
        print("✅ 旧的 build 文件夹已清除。")
    except Exception as e:
        print(f"⚠️ 无法删除 build 文件夹，请手动删除: {e}")

# 3. 执行打包命令
print("🚀 开始重新打包...")
# 注意：这里假设您的仓库名是 calc，如果不是请修改
cmd = 'flet build web --base-url "/calc/"'
os.system(cmd)

print("\n🎉 打包完成！请去 build/web 文件夹复制文件到 GitHub 仓库。")
