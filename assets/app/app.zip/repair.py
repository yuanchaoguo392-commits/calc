import os
import subprocess

def write_file(filename, content):
    print(f"🔧 正在重写 {filename} ...")
    with open(filename, "w", encoding="utf-8", newline="\n") as f:
        f.write(content.strip())

# 1. 重写 .fletignore (确保排除垃圾文件)
ignore_content = """
build
dist
venv
.venv
__pycache__
.git
.idea
*.pyc
"""
write_file(".fletignore", ignore_content)

# 2. 重写 requirements.txt (确保格式纯净)
req_content = """
flet
pandas
matplotlib
openpyxl
"""
write_file("requirements.txt", req_content)

# 3. 修正 main.py 的奇怪换行符
if os.path.exists("main.py"):
    print("🔧 正在修正 main.py 格式 ...")
    try:
        with open("main.py", "rb") as f:
            raw = f.read()
        # 将各种奇怪的换行符统一替换为标准 \n
        content = raw.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        with open("main.py", "wb") as f:
            f.write(content)
    except Exception as e:
        print(f"⚠️ 读取 main.py 失败: {e}")

# 4. 执行打包
print("🚀 开始重新打包...")
# 这里的 /calc/ 对应您的仓库名，如果改了请在这里也改
cmd = 'flet build web --base-url "/calc/"'
result = os.system(cmd)

if result == 0:
    print("\n✅ 打包成功！请去 build/web 文件夹查看。")
else:
    print("\n❌ 打包失败，请检查报错信息。")
